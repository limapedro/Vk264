# Wx264 Vulkan development handoff

Vulkan fork revision `31c9b63d185854eed697e30ac37b065ec70cb97a`.

The current experimental encoder runs through the CLI with `--backend vulkan --entropy cavlc`.
Its resident GPU pipeline is in `x264-vulkan/vulkan`. In particular, `dct_parity.cpp`
records the frame graph, `motion_search.comp` handles motion estimation and
compensation, `inter_frame.comp` prepares and gathers residual data,
`cavlc_frame.comp` assembles the slice, and `cavlc_packet.comp` builds the
Annex B packet. The root `shaders` folder is also required to build the CLI.

Start with [the Vulkan port notes](x264-vulkan/vulkan/README.md),
[the function inventory](x264-vulkan/vulkan/INVENTORY.md), and
[the latest pipeline map and timings](results/vulkan-cavlc-packet/performance.md).
The [tiling trial](results/vulkan-motion-tiles/performance.md) measured four
tile sizes and left tiling opt-in. The current 1080p benchmark bitstreams
match the previous build byte for byte. The latest paired runs measured
roughly 27 fps on a GTX 1660 SUPER.

## Build and check

From the folder that contains this file, use a Windows x64 C++ toolchain,
the Vulkan SDK with glslc, CMake, and Python 3. Put FFmpeg and FFprobe on
PATH for the reconstruction test.

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release --target wx264 dct_parity
ctest --test-dir build -C Release --output-on-failure -R vulkan_cavlc_reconstruction
```

The sources and selected reports are included. Build outputs, portable OBS,
raw footage, and captured encodes were omitted from the archive.
The [clip manifest](clips/youtube/manifest_1080p60.json) records the footage
used for file benchmarks. Reconstruction tests generate their own inputs.
