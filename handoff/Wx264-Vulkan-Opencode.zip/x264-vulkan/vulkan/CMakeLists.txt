cmake_minimum_required(VERSION 3.21)
project(x264_vulkan LANGUAGES CXX)

find_package(Vulkan REQUIRED COMPONENTS glslc)
find_package(Python3 REQUIRED COMPONENTS Interpreter)
foreach(side IN ITEMS 4 8)
    set(source "dct${side}x${side}.comp")
    foreach(group IN ITEMS 4 8 16)
        if(group LESS side)
            continue()
        endif()
        set(shader "${CMAKE_CURRENT_BINARY_DIR}/dct${side}x${side}_group${group}.spv")
        add_custom_command(OUTPUT "${shader}"
            COMMAND Vulkan::glslc --target-env=vulkan1.1 -O -DGROUP_SIDE=${group}
                    "${CMAKE_CURRENT_SOURCE_DIR}/${source}" -o "${shader}"
            DEPENDS "${source}" dct_layout.glsl dct4x4_math.glsl dct8x8_math.glsl VERBATIM)
        list(APPEND shaders "${shader}")
    endforeach()
    set(quant "${CMAKE_CURRENT_BINARY_DIR}/quant${side}x${side}.spv")
    add_custom_command(OUTPUT "${quant}"
        COMMAND Vulkan::glslc --target-env=vulkan1.1 -O -DSIDE=${side}
                "${CMAKE_CURRENT_SOURCE_DIR}/quant.comp" -o "${quant}"
        DEPENDS quant.comp quant_level.glsl VERBATIM)
    list(APPEND shaders "${quant}")
endforeach()
set(deblock_source "${CMAKE_CURRENT_SOURCE_DIR}/../common/deblock.c")
set(deblock_tables "${CMAKE_CURRENT_BINARY_DIR}/deblock_tables.glsl")
add_custom_command(OUTPUT "${deblock_tables}"
    COMMAND Python3::Interpreter "${CMAKE_CURRENT_SOURCE_DIR}/extract_reference.py"
            "${deblock_source}" "${deblock_tables}"
    DEPENDS extract_reference.py "${deblock_source}" VERBATIM)
set(shader_deps_deblock_filter "${deblock_tables}" deblock_math.glsl)
set(shader_deps_deblock_frame "${deblock_tables}" deblock_math.glsl)
set(shader_deps_dc chroma_hadamard.glsl quant_level.glsl luma_dc_math.glsl)
set(shader_deps_zigzag zigzag4_order.glsl zigzag8_order.glsl)
set(shader_deps_coeff_analysis decimate4_table.glsl decimate8_table.glsl)
set(shader_deps_inter8x8 dct8x8_math.glsl zigzag8_order.glsl decimate8_table.glsl quant_level.glsl inter8x8_fixture.glsl)
set(shader_deps_predict_intra predict_intra_math.glsl)
set(shader_deps_intra16 dct4x4_math.glsl luma_dc_math.glsl zigzag4_order.glsl
                       decimate4_table.glsl quant_level.glsl predict_intra_math.glsl macroblock4_order.glsl)
set(shader_deps_cabac macroblock4_order.glsl mv_predict_math.glsl)
set(shader_deps_mv_predict mv_predict_math.glsl)
list(APPEND shader_deps_intra16 macroblock4_math.glsl intra16_fixture.glsl)
set(shader_deps_intra_chroma dct4x4_math.glsl zigzag4_order.glsl quant_level.glsl
                            chroma_hadamard.glsl chroma_optimize_math.glsl predict_intra_math.glsl
                            macroblock4_math.glsl decimate4_table.glsl intra_chroma_fixture.glsl)
set(shader_deps_motion_metrics hadamard_magnitude.glsl)
set(shader_deps_chroma_dc chroma_hadamard.glsl)
set(shader_deps_chroma_optimize chroma_hadamard.glsl chroma_optimize_math.glsl)
set(shader_deps_quant_group quant_level.glsl)
set(shader_deps_motion_compensation motion_sampling.glsl)
set(shader_deps_motion_search motion_sampling.glsl hadamard4.glsl)
set(shader_deps_motion_bidir motion_sampling.glsl hadamard4.glsl)
set(shader_deps_bitstream bit_writer.glsl)
set(parameter_source "${CMAKE_CURRENT_SOURCE_DIR}/../common/set.h")
set(parameter_types "${CMAKE_CURRENT_BINARY_DIR}/parameter_types.glsl")
set(parameter_reference_types "${CMAKE_CURRENT_BINARY_DIR}/upstream_set_types.inc")
foreach(output IN ITEMS "${parameter_types}" "${parameter_reference_types}")
    add_custom_command(OUTPUT "${output}"
        COMMAND Python3::Interpreter "${CMAKE_CURRENT_SOURCE_DIR}/extract_reference.py"
                "${parameter_source}" "${output}"
        DEPENDS extract_reference.py "${parameter_source}" ../common/macroblock.h VERBATIM)
endforeach()
list(APPEND references "${parameter_reference_types}")
set(shader_deps_parameters bit_writer.glsl "${parameter_types}")
set(shader_deps_slice_header bit_writer.glsl "${parameter_types}")
set(stages dc zigzag chroma_dc reconstruct_dc quant_group coeff_analysis chroma_optimize
           predict_intra predict_directional deblock_filter deblock_frame deblock_strength cabac mv_predict motion_compensation
           motion_metrics motion_elimination motion_integral motion_lowres motion_search motion_bidir
           bitstream nal parameters slice_header intra16 intra_chroma inter8x8 cavlc_packet)
foreach(stage IN LISTS stages)
    set(shader "${CMAKE_CURRENT_BINARY_DIR}/${stage}.spv")
    add_custom_command(OUTPUT "${shader}"
        COMMAND Vulkan::glslc --target-env=vulkan1.1 -O "-I${CMAKE_CURRENT_BINARY_DIR}"
                "${CMAKE_CURRENT_SOURCE_DIR}/${stage}.comp" -o "${shader}"
        DEPENDS "${stage}.comp" ${shader_deps_${stage}} VERBATIM)
    list(APPEND shaders "${shader}")
endforeach()
foreach(unit IN ITEMS dct quant macroblock tables predict deblock cabac mvpred mc pixel me bitstream set encoder)
    set(reference "${CMAKE_CURRENT_BINARY_DIR}/upstream_${unit}.inc")
    set(folder common)
    if(unit MATCHES "^(macroblock|me|set|encoder)$")
        set(folder encoder)
    endif()
    set(extra_reference_deps)
    if(unit STREQUAL "me")
        set(extra_reference_deps ../encoder/me.h ../common/common.h ../common/base.h ../common/macroblock.h)
    elseif(unit STREQUAL "mvpred")
        set(extra_reference_deps ../common/base.h)
    elseif(unit STREQUAL "encoder")
        set(extra_reference_deps ../common/common.h)
    endif()
    add_custom_command(OUTPUT "${reference}"
        COMMAND Python3::Interpreter "${CMAKE_CURRENT_SOURCE_DIR}/extract_reference.py"
                "${CMAKE_CURRENT_SOURCE_DIR}/../${folder}/${unit}.c" "${reference}"
        DEPENDS extract_reference.py "../${folder}/${unit}.c" ${extra_reference_deps} VERBATIM)
    list(APPEND references "${reference}")
endforeach()
set(residual_reference "${CMAKE_CURRENT_BINARY_DIR}/upstream_cabac_residual.inc")
add_custom_command(OUTPUT "${residual_reference}"
    COMMAND Python3::Interpreter "${CMAKE_CURRENT_SOURCE_DIR}/extract_reference.py"
            "${CMAKE_CURRENT_SOURCE_DIR}/../encoder/cabac.c" "${residual_reference}"
    DEPENDS extract_reference.py ../encoder/cabac.c ../common/predict.h VERBATIM)
list(APPEND references "${residual_reference}")
set(bitwriter_reference "${CMAKE_CURRENT_BINARY_DIR}/upstream_bitwriter.inc")
add_custom_command(OUTPUT "${bitwriter_reference}"
    COMMAND Python3::Interpreter "${CMAKE_CURRENT_SOURCE_DIR}/extract_reference.py"
            "${CMAKE_CURRENT_SOURCE_DIR}/../common/bitstream.h" "${bitwriter_reference}"
    DEPENDS extract_reference.py ../common/bitstream.h VERBATIM)
list(APPEND references "${bitwriter_reference}")
set(intra_reference "${CMAKE_CURRENT_BINARY_DIR}/upstream_intra16.inc")
add_custom_command(OUTPUT "${intra_reference}"
    COMMAND Python3::Interpreter "${CMAKE_CURRENT_SOURCE_DIR}/extract_reference.py"
            "${CMAKE_CURRENT_SOURCE_DIR}/../encoder/macroblock.c" "${intra_reference}"
    DEPENDS extract_reference.py ../encoder/macroblock.c ../encoder/macroblock.h
            ../common/macroblock.c ../common/macroblock.h ../common/base.h ../common/set.c VERBATIM)
list(APPEND references "${intra_reference}")
set(cabac_frame "${CMAKE_CURRENT_BINARY_DIR}/cabac_frame.spv")
add_custom_command(OUTPUT "${cabac_frame}"
    COMMAND Vulkan::glslc --target-env=vulkan1.1 -O -DCABAC_MAX_BYTES=2097152
            -DCABAC_MAX_OPERATIONS=8192 -DCABAC_RESIDUAL_WORDS=3227648 -DCABAC_SHARED_FRAME=1
            "${CMAKE_CURRENT_SOURCE_DIR}/cabac.comp" -o "${cabac_frame}"
    DEPENDS cabac.comp ${shader_deps_cabac} VERBATIM)
list(APPEND shaders "${cabac_frame}")
set(cavlc_frame "${CMAKE_CURRENT_BINARY_DIR}/cavlc_frame.spv")
add_custom_command(OUTPUT "${cavlc_frame}"
    COMMAND Vulkan::glslc --target-env=vulkan1.1 -O
            "${CMAKE_CURRENT_SOURCE_DIR}/cavlc_frame.comp" -o "${cavlc_frame}"
    DEPENDS cavlc_frame.comp cavlc_residual.glsl macroblock4_order.glsl mv_predict_math.glsl VERBATIM)
list(APPEND shaders "${cavlc_frame}")
foreach(stage IN ITEMS intra16 inter8x8 intra_chroma)
    set(shader "${CMAKE_CURRENT_BINARY_DIR}/${stage}_frame.spv")
    add_custom_command(OUTPUT "${shader}"
        COMMAND Vulkan::glslc --target-env=vulkan1.1 -O -DRESIDUAL_FRAME=1
                "${CMAKE_CURRENT_SOURCE_DIR}/${stage}.comp" -o "${shader}"
        DEPENDS "${stage}.comp" ${shader_deps_${stage}} VERBATIM)
    list(APPEND shaders "${shader}")
endforeach()
set(inter_frame "${CMAKE_CURRENT_BINARY_DIR}/inter_frame.spv")
add_custom_command(OUTPUT "${inter_frame}"
    COMMAND Vulkan::glslc --target-env=vulkan1.1 -O
            "${CMAKE_CURRENT_SOURCE_DIR}/inter_frame.comp" -o "${inter_frame}"
    DEPENDS inter_frame.comp intra16_fixture.glsl inter8x8_fixture.glsl intra_chroma_fixture.glsl
            hadamard4.glsl macroblock4_order.glsl VERBATIM)
list(APPEND shaders "${inter_frame}")
foreach(stage IN ITEMS deblock_frame_tiled deblock_frame_subgroup)
    set(shader "${CMAKE_CURRENT_BINARY_DIR}/${stage}.spv")
    set(defines -DDEBLOCK_TILED=1)
    if(stage STREQUAL "deblock_frame_subgroup")
        list(APPEND defines -DDEBLOCK_SUBGROUP=1)
    endif()
    add_custom_command(OUTPUT "${shader}"
        COMMAND Vulkan::glslc --target-env=vulkan1.1 -O ${defines} "-I${CMAKE_CURRENT_BINARY_DIR}"
                "${CMAKE_CURRENT_SOURCE_DIR}/deblock_frame.comp" -o "${shader}"
        DEPENDS deblock_frame.comp ${shader_deps_deblock_frame} VERBATIM)
    list(APPEND shaders "${shader}")
endforeach()
set(reference_frame "${CMAKE_CURRENT_BINARY_DIR}/reference_frame.spv")
add_custom_command(OUTPUT "${reference_frame}"
    COMMAND Vulkan::glslc --target-env=vulkan1.1 -O
            "${CMAKE_CURRENT_SOURCE_DIR}/reference_frame.comp" -o "${reference_frame}"
    DEPENDS reference_frame.comp VERBATIM)
list(APPEND shaders "${reference_frame}")
foreach(stage IN ITEMS motion_frame motion_frame_parallel motion_frame_batched motion_frame_tiled)
    set(shader "${CMAKE_CURRENT_BINARY_DIR}/${stage}.spv")
    set(defines -DFRAME_MOTION=1)
    if(NOT stage STREQUAL "motion_frame")
        list(APPEND defines -DFRAME_MOTION_PARALLEL=1)
    endif()
    if(stage STREQUAL "motion_frame_batched" OR stage STREQUAL "motion_frame_tiled")
        list(APPEND defines -DFRAME_MOTION_BATCH=1)
    endif()
    if(stage STREQUAL "motion_frame_tiled")
        list(APPEND defines -DFRAME_MOTION_TILE=1)
    endif()
    add_custom_command(OUTPUT "${shader}"
        COMMAND Vulkan::glslc --target-env=vulkan1.1 -O ${defines}
                "${CMAKE_CURRENT_SOURCE_DIR}/motion_search.comp" -o "${shader}"
        DEPENDS motion_search.comp motion_sampling.glsl hadamard4.glsl mv_predict_math.glsl VERBATIM)
    list(APPEND shaders "${shader}")
endforeach()
set(rate_control "${CMAKE_CURRENT_BINARY_DIR}/rate_control.spv")
add_custom_command(OUTPUT "${rate_control}"
    COMMAND Vulkan::glslc --target-env=vulkan1.1 -O
            "${CMAKE_CURRENT_SOURCE_DIR}/rate_control.comp" -o "${rate_control}"
    DEPENDS rate_control.comp VERBATIM)
list(APPEND shaders "${rate_control}")
add_custom_target(dct_inputs DEPENDS ${shaders} ${references})

add_library(x264_vulkan_backend STATIC dct_parity.cpp)
add_dependencies(x264_vulkan_backend dct_inputs)
target_compile_features(x264_vulkan_backend PUBLIC cxx_std_17)
target_compile_definitions(x264_vulkan_backend PRIVATE X264_VULKAN_SHADER_DIR="${CMAKE_CURRENT_BINARY_DIR}")
if(MSVC)
    target_compile_options(x264_vulkan_backend PRIVATE /Zc:preprocessor)
endif()
target_include_directories(x264_vulkan_backend
    PUBLIC "${CMAKE_CURRENT_SOURCE_DIR}" PRIVATE "${CMAKE_CURRENT_BINARY_DIR}")
target_link_libraries(x264_vulkan_backend PRIVATE Vulkan::Vulkan)
add_executable(dct_parity parity_main.cpp)
target_link_libraries(dct_parity PRIVATE x264_vulkan_backend)
include(CTest)
foreach(stage IN LISTS stages)
    add_test(NAME x264_${stage}_parity
             COMMAND dct_parity ${stage} "${CMAKE_CURRENT_BINARY_DIR}/${stage}.spv")
endforeach()
add_test(NAME x264_reference_frame_parity
         COMMAND dct_parity reference_frame "${reference_frame}")
add_test(NAME x264_deblock_frame_tiled_parity
         COMMAND dct_parity deblock_frame_tiled "${CMAKE_CURRENT_BINARY_DIR}/deblock_frame_tiled.spv")
add_test(NAME x264_deblock_frame_subgroup_parity
         COMMAND dct_parity deblock_frame_subgroup "${CMAKE_CURRENT_BINARY_DIR}/deblock_frame_subgroup.spv")
set_tests_properties(x264_deblock_frame_subgroup_parity PROPERTIES SKIP_RETURN_CODE 77)
add_test(NAME x264_inter4x4_parity
         COMMAND dct_parity inter4x4 "${CMAKE_CURRENT_BINARY_DIR}/intra16.spv")
add_test(NAME x264_motion_exhaustive_parity
         COMMAND dct_parity motion_exhaustive "${CMAKE_CURRENT_BINARY_DIR}/motion_search.spv")
find_program(FFMPEG_EXECUTABLE ffmpeg)
find_program(FFPROBE_EXECUTABLE ffprobe)
set(smoke_probe)
if(FFPROBE_EXECUTABLE)
    set(smoke_probe "${FFPROBE_EXECUTABLE}")
endif()
if(FFMPEG_EXECUTABLE)
    foreach(mode IN ITEMS stream raw)
        set(raw_option)
        set(artifact "cabac-smoke")
        if(mode STREQUAL "raw")
            set(raw_option "--raw")
            set(artifact "cabac-raw")
        endif()
        add_test(NAME x264_cabac_${mode}_decode
                 COMMAND Python3::Interpreter "${CMAKE_CURRENT_SOURCE_DIR}/verify_cabac_stream.py"
                         "$<TARGET_FILE:dct_parity>" "${FFMPEG_EXECUTABLE}"
                         "${CMAKE_CURRENT_BINARY_DIR}/parameters.spv" "${CMAKE_CURRENT_BINARY_DIR}/slice_header.spv"
                         "${CMAKE_CURRENT_BINARY_DIR}/intra16.spv" "${CMAKE_CURRENT_BINARY_DIR}/intra_chroma.spv"
                         "${CMAKE_CURRENT_BINARY_DIR}/motion_compensation.spv"
                         "${CMAKE_CURRENT_BINARY_DIR}/mv_predict.spv" "${CMAKE_CURRENT_BINARY_DIR}/motion_search.spv"
                         "${cabac_frame}" "${CMAKE_CURRENT_BINARY_DIR}/nal.spv"
                         "${CMAKE_CURRENT_BINARY_DIR}/${artifact}.h264"
                         "${CMAKE_CURRENT_BINARY_DIR}/${artifact}-reconstructed.yuv"
                         ${smoke_probe} ${raw_option})
    endforeach()
endif()
foreach(side IN ITEMS 4 8)
    foreach(group IN ITEMS 4 8 16)
        if(group LESS side)
            continue()
        endif()
        add_test(NAME x264_dct${side}x${side}_group${group}_parity
                 COMMAND dct_parity ${side}x${group} "${CMAKE_CURRENT_BINARY_DIR}/dct${side}x${side}_group${group}.spv")
    endforeach()
    add_test(NAME x264_quant${side}x${side}_parity
             COMMAND dct_parity quant${side} "${CMAKE_CURRENT_BINARY_DIR}/quant${side}x${side}.spv")
endforeach()
